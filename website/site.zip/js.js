$("document").ready(function() {

    $('html,body').queue([]).stop(); //deze regel toevoegen stopt de vorige scroll animatie
    $('html, body').animate({
        scrollTop: $("#page1").offset().top
    }, 1000);

    $('#page1button').click(function(){
        $('html,body').queue([]).stop(); //deze regel toevoegen stopt de vorige scroll animatie
        $('html, body').animate({
            scrollTop: $("#page1").offset().top
        }, 1500);

    });

    $('#page2button').click(function(){
		$('html,body').queue([]).stop();
        $('html, body').animate({
            scrollTop: $("#page2").offset().top
        }, 1500);

    });

    $('#page3button').click(function(){
		$('html,body').queue([]).stop();
        $('html, body').animate({
            scrollTop: $("#page3").offset().top
        }, 1500);

    });

    $('#page4button').click(function(){
		$('html,body').queue([]).stop();
        $('html, body').animate({
            scrollTop: $("#page4").offset().top
        }, 1500);

    });
	
	$("#scrollmenu").hover(function(){  //Deze functie is toegevoegd om de navbar tevoorschijn te laten komen
		$('#scrollmenu').queue([]).stop(); //deze regel toevoegen stopt de vorige animatie
		$('#scrollmenu').animate({ //deze regel start de animatie
            top: '0px' });
			$('#scrollmenu').fadeTo('slow', 1);
		},function(){
		$('#scrollmenu').queue([]).stop(); //Deze functie is toegevoegd om de navbar te verbergen te laten komen
		$('#scrollmenu').animate({
            top: '-50px' });
		$('#scrollmenu').fadeTo('slow', 0.5);
	});

    $("#rightbutton").click(function(){  //Deze functie is toegevoegd om de navbar tevoorschijn te laten komen
        $('#content1').queue([]).stop(); //deze regel toevoegen stopt de vorige animatie

        if ($('#content1').is(":visible"))  {
            $('#content1').fadeTo('slow', 0);
            $('#content1').hide();
            $('#content2').show();
            $('#content2').fadeTo('slow', 1);
        }
        else if ($('#content2').is(":visible"))  {
            $('#content2').fadeTo('slow', 0);
            $('#content2').hide();
            $('#content3').show();
            $('#content3').fadeTo('slow', 1);
        }

        else if ($('#content3').is(":visible"))  {
            $('#content3').fadeTo('slow', 0);
            $('#content3').hide();
            $('#content4').show();
            $('#content4').fadeTo('slow', 1);
        }

        else if ($('#content4').is(":visible"))  {
            $('#content4').fadeTo('slow', 0);
            $('#content4').hide();
            $('#content1').show();
            $('#content1').fadeTo('slow', 1);
        }
    });

    $("#leftbutton").click(function(){
        $('#content2').queue([]).stop(); //Deze functie is toegevoegd om de navbar te verbergen te laten komen


        if ($('#content1').is(":visible"))  {
            $('#content1').fadeTo('slow', 0);
            $('#content1').hide();
            $('#content4').show();
            $('#content4').fadeTo('slow', 1);
        }
        else if ($('#content2').is(":visible"))  {
            $('#content2').fadeTo('slow', 0);
            $('#content2').hide();
            $('#content1').show();
            $('#content1').fadeTo('slow', 1);
        }

        else if ($('#content3').is(":visible"))  {
            $('#content3').fadeTo('slow', 0);
            $('#content3').hide();
            $('#content2').show();
            $('#content2').fadeTo('slow', 1);
        }

        else if ($('#content4').is(":visible"))  {
            $('#content4').fadeTo('slow', 0);
            $('#content4').hide();
            $('#content3').show();
            $('#content3').fadeTo('slow', 1);
        }
    });



});
